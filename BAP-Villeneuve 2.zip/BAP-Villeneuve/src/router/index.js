import { createRouter, createWebHistory } from "vue-router";
import Accueil from "../components/Accueil.vue";
import Map from "../components/Map.vue";

const routes = [
    { path: "/", component: Accueil }, // Route vers la page d'accueil
    { path: "/map", component: Map }, // Route vers la carte des associations
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

export default router;
