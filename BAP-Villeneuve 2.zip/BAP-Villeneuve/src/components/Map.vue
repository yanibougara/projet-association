<template>
    <div>
        <div class="navbar">
            <h3>
                <router-link to="/">Accueil</router-link>
                /
                <a href="" target="_blank" rel="noopener">jsp</a>.
            </h3>
        </div>
        <div class="titre">
            <h1 class="green">Carte des associations</h1>
        </div>
        <div id="map" ref="mapContainer"></div>
    </div>
</template>

<script>
import { ref, onMounted } from "vue";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export default {
    name: "Map",
    setup() {
        const mapContainer = ref(null);

        onMounted(() => {
            const mapInstance = L.map(mapContainer.value).setView(
                [48.9361, 2.3319],
                15.4
            );

            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                maxZoom: 20,
            }).addTo(mapInstance);

            // Exemple d'ajout de marqueur (à commenter ou supprimer si vous ne l'utilisez pas)
            L.marker([48.9361, 2.3319]).addTo(mapInstance); // Ajoute un marqueur à Villeneuve-la-Garenne (coordonnées par défaut)
            L.marker([48.9361, 2.3399]).addTo(mapInstance); // Ajoute un marqueur à Villeneuve-la-Garenne (coordonnées par défaut)
            L.marker([48.9361, 2.3339]).addTo(mapInstance); // Ajoute un marqueur à Villeneuve-la-Garenne (coordonnées par défaut)
            L.marker([48.9391, 2.3389]).addTo(mapInstance); // Ajoute un marqueur à Villeneuve-la-Garenne (coordonnées par défaut)
        });

        return {
            mapContainer,
        };
    },
};
</script>

<style>
#map {
    height: 500px;
    width: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 25% auto;
    border-radius: 20px;
    box-shadow: 0 0 1000px aliceblue;
        margin-top: 2%;

}

body {
    background: rgb(2, 0, 36);
    background: linear-gradient(
        90deg,
        rgba(2, 0, 36, 1) 0%,
        rgba(9, 9, 121, 1) 20%,
        rgba(0, 212, 255, 1) 100%
    );
}

.titre {
    color: wheat;
    margin: 10% auto;
    text-align: center;
    font-family: HighVoltage Heavy Rough;
    font-size: 300%;
}

.navbar {
    background-color: rgb(54, 188, 221);
    width: 100%;
    height: 100px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: rgb(2, 0, 36);
    background: linear-gradient(
        90deg,
        rgba(2, 0, 36, 1) 0%,
        rgba(9, 9, 121, 1) 20%,
        rgb(23, 192, 226) 50%
    );
}

.navbar h3 {
    color: wheat;
    font-family: HighVoltage Heavy Rough;
    font-size: 200%;
    text-decoration: none;
}

.green {
    margin-top: -9%;
}
</style>
