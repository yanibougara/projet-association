<template>
  <div class="accueil">
    <h1>Bienvenue sur notre application</h1>
    <router-link to="/map">Voir la carte des associations</router-link>
    <!-- Ajoutez d'autres liens vers différentes parties de votre application si nécessaire -->
  </div>
</template>

<script>
export default {
  name: 'Accueil',
};
</script>

<style scoped>
.accueil {
  text-align: center;
  margin-top: 100px;
}

.accueil h1 {
  color: #333;
  font-size: 24px;
  margin-bottom: 20px;
}

.accueil a {
  display: block;
  color: #007bff;
  font-size: 18px;
  margin-bottom: 10px;
}
</style>
