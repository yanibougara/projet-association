<script setup>
import { defineComponent } from 'vue';
import Map from './components/Map.vue';
</script>

<template>
  <div id="app">
    <Map />
  </div>
</template>

<script>
export default defineComponent({
  name: 'App',
  components: {
    Map,
  },
});
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  
}
</style>

